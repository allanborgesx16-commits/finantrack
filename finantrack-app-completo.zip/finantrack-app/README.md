# FinanTrack - Guia Completo de Instalação e Publicação

Este projeto contém o código completo do **FinanTrack**, pronto para rodar na Web (Vercel) e compilar o arquivo APK do Android via GitHub Actions de maneira 100% gratuita.

---

## 🚀 Passo 1: Configurar o Supabase (Banco de Dados & Login)

1. Acesse seu painel no [Supabase](https://supabase.com/) e crie um novo projeto gratuito.
2. No menu lateral, clique em **SQL Editor**.
3. Abra o arquivo `supabase-schema.sql` deste projeto, copie todo o conteúdo, cole no SQL Editor do Supabase e clique em **Run**.
4. No menu lateral, vá em **Project Settings** > **API**.
5. Copie a **Project URL** e a chave pública **anon / public key**.
6. No seu projeto, renomeie `.env.example` para `.env` e cole suas duas chaves.

---

## 🌐 Passo 2: Publicar a Versão Web na Vercel (100% Gratuito)

1. Crie um novo repositório no seu [GitHub](https://github.com/) e suba todos os arquivos deste projeto.
2. Acesse a [Vercel](https://vercel.com/), faça login com seu GitHub e clique em **Add New Project**.
3. Selecione o repositório do FinanTrack.
4. Na seção **Environment Variables**, adicione as duas variáveis do Supabase (`VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`).
5. Clique em **Deploy**. Em cerca de 1 minuto seu app estará no ar com link seguro HTTPS!

---

## 🤖 Passo 3: Compilar o APK do Android de Graça (GitHub Actions)

Você **não precisa instalar o Android Studio**. O arquivo `.github/workflows/build-apk.yml` compila o APK automaticamente nos servidores do GitHub:

1. Quando você enviar o código para o GitHub (`git push`), acesse o seu repositório no navegador.
2. Clique na aba **Actions**.
3. Você verá o processo **Compilar APK Android Gratuito** em execução.
4. Ao concluir (leva cerca de 3 a 5 minutos), clique na execução finalizada.
5. Na seção **Artifacts**, baixe o arquivo `FinanTrack-App-Android.apk` direto para o seu celular e instale!
