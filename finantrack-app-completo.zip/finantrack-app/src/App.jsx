import React, { useState, useEffect } from 'react';
import { supabase } from './lib/supabaseClient';

export default function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState('login'); // login | register
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [toast, setToast] = useState(null);

  // App data
  const [transactions, setTransactions] = useState([]);
  const [activeTab, setActiveTab] = useState('dashboard'); // dashboard | transactions | settings
  const [filterType, setFilterType] = useState('all');

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [txType, setTxType] = useState('income');
  const [txAmount, setTxAmount] = useState('');
  const [txDesc, setTxDesc] = useState('');
  const [txCategory, setTxCategory] = useState('Salário');
  const [txDate, setTxDate] = useState(new Date().toISOString().split('T')[0]);

  const categories = {
    income: ['Salário', 'Freelance', 'Investimentos', 'Vendas', 'Outros'],
    expense: ['Alimentação', 'Moradia', 'Transporte', 'Lazer', 'Saúde', 'Educação', 'Contas', 'Outros']
  };

  function showNotification(msg, type = 'info') {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }

  // Supabase Auth listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
      if (session) fetchTransactions(session.user.id);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) fetchTransactions(session.user.id);
      else setTransactions([]);
    });

    return () => subscription.unsubscribe();
  }, []);

  async function fetchTransactions(userId) {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', userId)
        .order('date', { ascending: false });

      if (error) throw error;
      setTransactions(data || []);
    } catch (err) {
      console.warn('Erro ao carregar transações:', err.message);
    }
  }

  async function handleAuth(e) {
    e.preventDefault();
    try {
      if (authMode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        showNotification('Login realizado com sucesso!', 'success');
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { name } }
        });
        if (error) throw error;
        showNotification('Conta criada com sucesso! Verifique seu e-mail.', 'success');
      }
    } catch (err) {
      showNotification(err.message, 'error');
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    showNotification('Sessão encerrada.', 'info');
  }

  async function handleAddTransaction(e) {
    e.preventDefault();
    const amountNum = parseFloat(txAmount);
    if (!amountNum || amountNum <= 0) {
      showNotification('Digite um valor positivo válido.', 'error');
      return;
    }

    try {
      const newTx = {
        user_id: session.user.id,
        type: txType,
        amount: amountNum,
        description: txDesc,
        category: txCategory,
        date: txDate
      };

      const { data, error } = await supabase.from('transactions').insert([newTx]).select();
      if (error) throw error;

      setTransactions([data[0], ...transactions]);
      setModalOpen(false);
      setTxAmount('');
      setTxDesc('');
      showNotification(txType === 'income' ? 'Recebimento salvo!' : 'Gasto registrado!', 'success');
    } catch (err) {
      showNotification(err.message, 'error');
    }
  }

  async function handleDeleteTransaction(id) {
    try {
      const { error } = await supabase.from('transactions').delete().eq('id', id);
      if (error) throw error;
      setTransactions(transactions.filter(t => t.id !== id));
      showNotification('Transação removida.', 'info');
    } catch (err) {
      showNotification(err.message, 'error');
    }
  }

  // Cálculos
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((acc, c) => acc + Number(c.amount), 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((acc, c) => acc + Number(c.amount), 0);
  const currentBalance = totalIncome - totalExpense;

  const filteredList = transactions.filter(t => {
    if (filterType === 'all') return true;
    return t.type === filterType;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 text-sm">
        Carregando FinanTrack...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between max-w-md mx-auto relative shadow-2xl">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl text-xs font-semibold shadow-xl border ${
          toast.type === 'success' ? 'bg-emerald-600 border-emerald-500' :
          toast.type === 'error' ? 'bg-rose-600 border-rose-500' : 'bg-slate-800 border-slate-700'
        }`}>
          {toast.msg}
        </div>
      )}

      {/* TELA DE LOGIN QUANDO DESLOGADO */}
      {!session ? (
        <div className="flex-1 flex flex-col justify-center px-6 py-12">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-8 shadow-xl text-center">
            <div className="w-16 h-16 bg-gradient-to-tr from-emerald-500 to-teal-400 rounded-2xl mx-auto flex items-center justify-center text-2xl shadow-lg shadow-emerald-500/20 mb-4">
              💰
            </div>
            <h1 className="text-2xl font-bold text-white">FinanTrack</h1>
            <p className="text-xs text-slate-400 mt-1 mb-6">Recebimentos e Gastos na Nuvem</p>

            <div className="flex bg-slate-950 p-1 rounded-xl mb-6 border border-slate-800">
              <button 
                onClick={() => setAuthMode('login')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${authMode === 'login' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>
                Entrar
              </button>
              <button 
                onClick={() => setAuthMode('register')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${authMode === 'register' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>
                Criar Conta
              </button>
            </div>

            <form onSubmit={handleAuth} className="space-y-3.5 text-left">
              {authMode === 'register' && (
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Nome Completo</label>
                  <input 
                    type="text" 
                    value={name} 
                    onChange={e => setName(e.target.value)} 
                    placeholder="Seu nome"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500" 
                    required 
                  />
                </div>
              )}
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">E-mail</label>
                <input 
                  type="email" 
                  value={email} 
                  onChange={e => setEmail(e.target.value)} 
                  placeholder="seu@email.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500" 
                  required 
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Senha</label>
                <input 
                  type="password" 
                  value={password} 
                  onChange={e => setPassword(e.target.value)} 
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500" 
                  required 
                />
              </div>
              <button 
                type="submit" 
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 rounded-xl text-xs shadow-lg shadow-emerald-500/20 transition-all mt-2">
                {authMode === 'login' ? 'Acessar Conta' : 'Finalizar Cadastro'}
              </button>
            </form>
          </div>
        </div>
      ) : (
        /* APP PRINCIPAL LOGADO */
        <div className="flex-1 flex flex-col pb-20">
          {/* Top Bar */}
          <header className="px-5 py-4 bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-xs text-white">
                {session.user.email[0].toUpperCase()}
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Conectado como</span>
                <span className="text-xs font-bold text-white truncate max-w-[160px] block">{session.user.email}</span>
              </div>
            </div>
            <span className="text-[10px] bg-emerald-500/15 text-emerald-400 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
              ● Supabase
            </span>
          </header>

          <main className="p-4 space-y-5 flex-1">
            {activeTab === 'dashboard' && (
              <>
                {/* Cartão de Saldo */}
                <div className="bg-gradient-to-br from-slate-900 to-slate-850 border border-slate-800 rounded-3xl p-5 shadow-xl">
                  <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Saldo Líquido</span>
                  <div className="text-3xl font-black text-white mt-1 mb-5">
                    R$ {currentBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-slate-800">
                    <div className="bg-slate-950/70 p-3 rounded-2xl border border-emerald-500/20">
                      <span className="text-[10px] text-slate-400 block">Recebimentos</span>
                      <span className="text-xs font-bold text-emerald-400">
                        + R$ {totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="bg-slate-950/70 p-3 rounded-2xl border border-rose-500/20">
                      <span className="text-[10px] text-slate-400 block">Gastos</span>
                      <span className="text-xs font-bold text-rose-400">
                        - R$ {totalExpense.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Ações Rápidas */}
                <div className="grid grid-cols-2 gap-2.5">
                  <button 
                    onClick={() => { setTxType('income'); setTxCategory(categories.income[0]); setModalOpen(true); }}
                    className="py-3 px-4 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-400 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5">
                    <span>+</span> Nova Receita
                  </button>
                  <button 
                    onClick={() => { setTxType('expense'); setTxCategory(categories.expense[0]); setModalOpen(true); }}
                    className="py-3 px-4 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-400 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5">
                    <span>-</span> Novo Gasto
                  </button>
                </div>

                {/* Últimas Transações */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">Últimos Registros</h3>
                    <button onClick={() => setActiveTab('transactions')} className="text-[11px] text-emerald-400 font-semibold">Ver todos</button>
                  </div>
                  {transactions.slice(0, 4).map(t => (
                    <div key={t.id} className="bg-slate-900 border border-slate-800 p-3 rounded-2xl flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
                          t.type === 'income' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {t.type === 'income' ? '↓' : '↑'}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-white">{t.description}</p>
                          <p className="text-[10px] text-slate-400">{t.category} • {t.date}</p>
                        </div>
                      </div>
                      <span className={`text-xs font-bold ${t.type === 'income' ? 'text-emerald-400' : 'text-slate-200'}`}>
                        {t.type === 'income' ? '+' : '-'} R$ {Number(t.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  ))}
                  {transactions.length === 0 && (
                    <div className="text-center p-6 text-slate-500 text-xs bg-slate-900 border border-slate-800 rounded-2xl">
                      Nenhuma transação cadastrada ainda.
                    </div>
                  )}
                </div>
              </>
            )}

            {activeTab === 'transactions' && (
              <div className="space-y-3">
                <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-bold">
                  <button onClick={() => setFilterType('all')} className={`flex-1 py-1.5 rounded-lg ${filterType === 'all' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>Todas</button>
                  <button onClick={() => setFilterType('income')} className={`flex-1 py-1.5 rounded-lg ${filterType === 'income' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>Receitas</button>
                  <button onClick={() => setFilterType('expense')} className={`flex-1 py-1.5 rounded-lg ${filterType === 'expense' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>Gastos</button>
                </div>

                <div className="space-y-2">
                  {filteredList.map(t => (
                    <div key={t.id} className="bg-slate-900 border border-slate-800 p-3 rounded-2xl flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-white">{t.description}</p>
                        <p className="text-[10px] text-slate-400">{t.category} • {t.date}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-bold ${t.type === 'income' ? 'text-emerald-400' : 'text-slate-200'}`}>
                          {t.type === 'income' ? '+' : '-'} R$ {Number(t.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                        <button onClick={() => handleDeleteTransaction(t.id)} className="text-slate-600 hover:text-rose-400 text-xs p-1">✕</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Sua Conta</span>
                  <p className="text-xs font-bold text-white mt-1">{session.user.email}</p>
                </div>
                <button 
                  onClick={handleLogout}
                  className="w-full py-3 bg-rose-500/15 border border-rose-500/30 text-rose-400 font-bold rounded-2xl text-xs">
                  Sair da Conta
                </button>
              </div>
            )}
          </main>

          {/* Bottom Nav */}
          <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-slate-900/90 backdrop-blur-md border-t border-slate-800 flex justify-around items-center h-16 px-4">
            <button onClick={() => setActiveTab('dashboard')} className={`text-xs font-bold ${activeTab === 'dashboard' ? 'text-emerald-400' : 'text-slate-400'}`}>Início</button>
            <button 
              onClick={() => { setTxType('income'); setTxCategory(categories.income[0]); setModalOpen(true); }}
              className="w-12 h-12 bg-emerald-500 text-white rounded-full flex items-center justify-center text-xl font-bold -translate-y-3 shadow-lg shadow-emerald-500/30">
              +
            </button>
            <button onClick={() => setActiveTab('transactions')} className={`text-xs font-bold ${activeTab === 'transactions' ? 'text-emerald-400' : 'text-slate-400'}`}>Extrato</button>
            <button onClick={() => setActiveTab('settings')} className={`text-xs font-bold ${activeTab === 'settings' ? 'text-emerald-400' : 'text-slate-400'}`}>Ajustes</button>
          </nav>
        </div>
      )}

      {/* Modal Nova Transação */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end justify-center p-0">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-t-3xl p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-bold text-white">Nova Movimentação</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleAddTransaction} className="space-y-3">
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button 
                  type="button" 
                  onClick={() => { setTxType('income'); setTxCategory(categories.income[0]); }}
                  className={`py-2 text-xs font-bold rounded-lg ${txType === 'income' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>
                  Recebimento
                </button>
                <button 
                  type="button" 
                  onClick={() => { setTxType('expense'); setTxCategory(categories.expense[0]); }}
                  className={`py-2 text-xs font-bold rounded-lg ${txType === 'expense' ? 'bg-rose-500 text-white' : 'text-slate-400'}`}>
                  Gasto
                </button>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Valor (R$)</label>
                <input 
                  type="number" 
                  step="0.01" 
                  required 
                  value={txAmount} 
                  onChange={e => setTxAmount(e.target.value)} 
                  placeholder="0,00"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" 
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Descrição</label>
                <input 
                  type="text" 
                  required 
                  value={txDesc} 
                  onChange={e => setTxDesc(e.target.value)} 
                  placeholder="Ex: Aluguel, Salário..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" 
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Categoria</label>
                <select 
                  value={txCategory} 
                  onChange={e => setTxCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500">
                  {(categories[txType] || []).map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Data</label>
                <input 
                  type="date" 
                  required 
                  value={txDate} 
                  onChange={e => setTxDate(e.target.value)} 
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" 
                />
              </div>
              <button 
                type="submit" 
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 rounded-xl text-xs shadow-lg shadow-emerald-500/20 transition-all mt-3">
                Salvar Movimentação
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
